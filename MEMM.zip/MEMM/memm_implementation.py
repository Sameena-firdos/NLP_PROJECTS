import pickle
import nltk
from nltk.tokenize import sent_tokenize,word_tokenize
from collections import OrderedDict
import math










def testdata(dict_obs,text):
	text=text.lower()
	testlis_state=[]
	testlis_state2=[]
	testlis_obs=[]
	i=0
	while(len(text)>0):
		i=0
		try:
			r,text = text.split('\n\n',1)
			#print text
			if i==0:
				testlis_state.append('/sw')
				testlis_obs.append('/sw')
				testlis_state2.append('/sw')
			while(len(r)>0):
				#i=0
				try:
					
					s,r=r.split('\n',1)
					#print s,"hjtfd\n"
					if (len(s)!=0):
						temp=s.split("\t")
						testlis_state.append(temp[1])
						testlis_state2.append(temp[2])
						testlis_obs.append(temp[0])


				except:
					#print r
					if (len(r)!=0):
						temp=r.split("\t")
						testlis_state.append(temp[1])
						testlis_state2.append(temp[2])
						testlis_obs.append(temp[0])
					break
				i+=1
			testlis_state.append('/ew')
			testlis_state2.append('/ew')
			testlis_obs.append('/ew')


			#print " "
			#print " "
		except:
			break

	#print " "
	#print " "
	testlis_state.append('/sw')
	testlis_state2.append('/sw')
	testlis_obs.append('/sw')
	while(len(text)>0):
		try:
			s,text=text.split('\n',1)
			if s=='\n':
				break
			#print s,"hjtfd"
			if len(s)!=0:
				temp=s.split("\t")
				testlis_state.append(temp[1])
				testlis_state2.append(temp[2])
				testlis_obs.append(temp[0])
		except:
			#print text
			if(len(text)!=0):
				temp=text.split("\t")
				testlis_state.append(temp[1])
				testlis_state2.append(temp[2])
				ltestis_obs.append(temp[0])
			break
	testlis_state.append('/ew')
	testlis_state2.append('/ew')
	testlis_obs.append('/ew')


	
	if testlis_obs[len(testlis_obs)-1]=='/ew' and testlis_obs[len(testlis_obs)-2]=='/sw':
		del testlis_obs[len(testlis_obs)-2:len(testlis_obs)]
	if testlis_state[len(testlis_state)-1]=='/ew' and testlis_state[len(testlis_state)-2]=='/sw':
		del testlis_state[len(testlis_state)-2:len(testlis_state)]
	if testlis_state2[len(testlis_state2)-1]=='/ew' and testlis_state2[len(testlis_state2)-2]=='/sw':
		del testlis_state2[len(testlis_state2)-2:len(testlis_state2)]
	tt=[]

	for i in range(0,len(testlis_obs)):

		tt.append(testlis_obs[i])
		if testlis_obs[i] not in dict_obs:
			testlis_obs[i]='<unk>'

	return testlis_obs,testlis_state,testlis_state2,tt


def call_viterbi(dict_postag,dict_obs,dict1,dict2,dict_past_tag,dict_updated_ftags,observation,state,lis_obs,lis_state1,dict_future_tag):
	#print state
	#print "updated future tag",dict_updated_ftags
	#print "updated previous tags",dict_past_tag
	#print "future ",dict_future_tag
	#print "the observation is\n",observation
	v=[]
	b=[]
	w1=0;w2=0;w3=0;w4=0;w5=0
	f1=0;f2=0;f3=0;f4=0;f5=1
	if len(observation)==1:
		#for class b
		val=[]
		for i in state:
			f1=1;f2=1;f3=0;f4=0;f5=1
			w1=dict1[i][1]/(float)(dict1[i][0])
			w2=dict1[i][2]/(float)(dict1[i][0])
			try:
				w5=dict2[i][observation[0]]/(float)(dict1[i][0])
			except:
				w5=0
			val.append(math.e**(w1*f1+w2*f2+w5*f5))
		tot=0
		for i in val:
			tot+=i
		p_c=[]
		for i in val:
			p_c.append(i/(float)(tot))
		val=-1
		index=-1
		for i in range(0,len(p_c)):
			if val<p_c[i]:
				index=i
				val=p_c[i]
		#print 'probabiliy matrix at each state is ',p_c
		#print "class os given observation is ",state[index]


	else:
		#calculating viterbi with satrt
		#print "in start"

		val=[]
		for i in state:
			f1=1;f2=0;f3=0;f4=0;f5=1
			w1=0;w2=0;w3=0;w4=0;w5=0
			w1=dict1[i][1]/(float)(dict1[i][0])
			#print w1

			try:
				#print "in try"
				#w2=dict1[i][2]/(float)(dict1[i][0])
				next_word=observation[1]
				ind=-1
				for k in range(0,len(lis_obs)):
					if lis_obs[k]==next_word:
						ind=k
						break
				next_tag=lis_state1[ind]
				if dict_updated_ftags[next_word]==next_tag:
					f4=1
					w4=dict_future_tag[next_word][next_tag]/(float)(dict_postag[next_tag])
				else:
					f4=0
					w4=0
				#print "f4 value is",f4,"next tag was ",next_tag,"next word was ",next_word

			except:
				pass

			try:
				w5=dict2[i][observation[0]]/(float)(dict1[i][0])
			except:
				w5=0
			val.append(math.e**(w1*f1+w2*f2+w3*f3+w4*f4+w5*f5))
		tot=0
		for i in val:
			tot+=i
		p_c=[]
		for i in val:
			p_c.append(i/(float)(tot))
		#print p_c

		temp1=[]
		temp2=[]
		
		#print temp1
		#print temp2
		st=''
		max=-1
		for pr in range(0,3):
			#print prev," ",l
			#print v[l][prev]
			if max<p_c[pr]:
				max=p_c[pr]
				st=pr
		for i in p_c:
			temp1.append(i)
			temp2.append(st)
		v.append(temp1)
		b.append(temp2)
		#print "viterbi on start\n",v
		#print "backtrac on start\n",b
		for i in state:
			print i

		#calculating intermadiate viterbi
		#print "in intermediate"
		#print "dict2 is",dict2

		for i in range(1,len(observation)-1):
			val=[]
			for s in state:
				f1=0;f2=0;f3=1;f4=1;f5=1
				try:
					w5=dict2[s][observation[i]]/(float)(dict1[s][0])
					#print "w5 as in",w5
				except:
					w5=0
					#print "s is",s
					#print "i is ",i
					#print "w5 in exception"

				try:
				#print "in try"
				#w2=dict1[i][2]/(float)(dict1[i][0])
					prev_word=observation[i-1]
					ind=-1
					for k in range(0,len(lis_obs)):
						if lis_obs[k]==prev_word:
							ind=k
							break
					prev_tag=lis_state1[ind]
					if prev_tag in dict_past_tag[prev_word]:
						f3=1

						w3=dict_past_tag[prev_word][prev_tag]/(float)(dict_postag[prev_tag])
					else:
						f3=0
						w3=0
					#print "f3 value is",f3,"next tag was ",prev_tag,"next word was ",prev_word

				except:
					pass
				try:
				#print "in try"
				#w2=dict1[i][2]/(float)(dict1[i][0])
					next_word=observation[i+1]
					ind=-1
					for k in range(0,len(lis_obs)):
						if lis_obs[k]==next_word:
							ind=k
							break
					next_tag=lis_state1[ind]
					if dict_updated_ftags[next_word]==next_tag:
						f4=1
						w4=dict_future_tag[next_word][next_tag]/(float)(dict_postag[next_tag])
					else:
						f4=0
						w4=0
				#print "f4 value is",f4,"next tag was ",next_tag,"next word was ",next_word

				except:
					pass
				val.append(math.e**(w1*f1+w2*f2+w3*f3+w4*f4+w5*f5))
			l=(len(v)-1)
			#print l
			st=''
			max=-1
			for prev in range(0,3):
				#print prev," ",l
				#print v[l][prev]
				if max<v[l][prev]:
					max=v[l][prev]
					st=prev


			tot=0
			for i in val:
				tot+=i
			p_c=[]
			#print "total is",tot
			#print 
			for i in val:
				#print "i in val is ",i
				p_c.append(i/(float)(tot))
			#print "jhellllllllllll",p_c

			temp1=[]
			temp2=[]
			for i in p_c:
				#print "update verti value ",i*max
				temp1.append(i*max)
				temp2.append(st)
			#print temp1
			#print temp2
			v.append(temp1)
			b.append(temp2)
			#print "ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss"
			#print "viterbi in intermediate\n",v
			#print "backtrac on intermadiate\n",b


			


		#calculating end viterbi\
		#print "in end"
		val=[]
		for i in state:
			f1=0;f2=1;f3=0;f4=0;f5=1 #f3 is conditional here
			w1=0;w2=0;w3=0;w4=0;w5=0
			w2=dict1[i][2]/(float)(dict1[i][0])
			#print w1

			try:
				#print "in try"
				#w2=dict1[i][2]/(float)(dict1[i][0])
				prev_word=observation[len(observation)-2]
				ind=-1
				for k in range(0,len(lis_obs)):
					if lis_obs[k]==prev_word:
						ind=k
						break
				prev_tag=lis_state1[ind]
				if prev_tag in dict_past_tag[prev_word]:
					f3=1

					w3=dict_past_tag[prev_word][prev_tag]/(float)(dict_postag[prev_tag])
				else:
					f3=0
					w3=0
				#print "f3 value is",f3,"next tag was ",prev_tag,"next word was ",prev_word

			except:
				pass

			try:
				w5=dict2[i][observation[len(observation)-1]]/(float)(dict1[i][0])
			except:
				w5=0
			val.append(math.e**(w1*f1+w2*f2+w3*f3+w4*f4+w5*f5))
		l=(len(v)-1)
		st=''
		max=-1
		for prev in range(0,3):
			if max<v[l][prev]:
				max=v[l][prev]
				st=prev


		tot=0
		for i in val:
			tot+=i
		p_c=[]
		for i in val:
			p_c.append(i/(float)(tot))
		#print p_c

		temp1=[]
		temp2=[]
		for i in p_c:
			temp1.append(i*max)
			temp2.append(st)
		#print temp1
		#print temp2
		v.append(temp1)
		b.append(temp2)
		#print "viterbi in end ", v
		#print "backtrack in end ",b
		#print b


		#backtrace

		observed_tag=[]
		l=(len(v)-1)
		st=''
		max=-1
		for prev in range(0,3):
			if max<v[l][prev]:
				max=v[l][prev]
				x=l
				y=prev
		
		observed_tag.append(y)

		for x in range (len(observation)-1,0,-1):
			if x==len(observation)-1:
				observed_tag.append(b[x][y])
				y=b[x][y]
			else:
				observed_tag.append(b[x][y])
				y=b[x][y]
		observed_tag.reverse()

		#print observed_tag
		return observed_tag




def sent_viterbi(tt,dict_postag,dict_obs,dict1,dict2,dict_past_tag,dict_updated_ftags,testlis_obs,testlis_state,lis_obs,lis_state1,dict_future_tag,testlis_state2):
	state=[]
	st=[]
	state.append('B')
	state.append('I')
	state.append('O')
	st.append('b-np')
	st.append('i-np')
	st.append('o')
	observation=[]
	ls=[]
	ls2=[]
	tti=[]
	#print "tt ",tt
	#print ls
	#print ls2
	#print observed_tag
	accuracy={'b-np':[0,0],'i-np':[0,0],'o':[0,0]}#correct count with total count
	for i in range(0,len(testlis_obs)):
		if testlis_obs[i]=='/sw':
			continue
		elif testlis_obs[i]=='/ew':
			observed_tag=call_viterbi(dict_postag,dict_obs,dict1,dict2,dict_past_tag,dict_updated_ftags,observation,state,lis_obs,lis_state1,dict_future_tag)
			for i in range(0,len(observation)):
				f = open("memm_output", "a")
				#print "tt ",tt
				#print "ls",ls
				#print "ls2",ls2
				#print "observed_tag",observed_tag
				try:
					f.write(tti[i]+"\t"+ls[i]+"\t"+ls2[i]+"\t"+st[observed_tag[i]])
				except:
					continue
				if ls2[i]==st[observed_tag[i]]:
					accuracy[ls2[i]][0]+=1
				accuracy[ls2[i]][1]+=1
				f.write('\n')
			f.write('\n')
			f.close()			

			observation=[]
			ls=[]
			ls2=[]
			tti=[]

			#state=[]
		else:
			#state.append(testlis_state[i])
			observation.append(testlis_obs[i])
			tti.append(tt[i])
			ls.append(testlis_state[i])
			ls2.append(testlis_state2[i])
	#accuracy
	print "Accuracy for b-np tag is ",(accuracy['b-np'][0]/(float)(accuracy['b-np'][1]))*100
	print "Accuracy for i-np tag is ",(accuracy['i-np'][0]/(float)(accuracy['i-np'][1]))*100
	print "Accuracy for o tag is ",(accuracy['o'][0]/(float)(accuracy['o'][1]))*100











def read_trainingdata(name):
	class1= open(name, 'rb')
	return(pickle.load(class1))





print "Enter file for memm testing"
text=raw_input()

text = open(text, 'r')
text=text.read()
dict_postag=read_trainingdata('dict_postag')
dict_obs=read_trainingdata('dict_obs')
dict1=read_trainingdata('dict1')
dict2=read_trainingdata('dict2')
dict_past_tag=read_trainingdata('dict_past_tag')
dict_updated_ftags=read_trainingdata('dict_updated_ftags')
dict_future_tag=read_trainingdata('dict_future_tag')
lis_obs=read_trainingdata('lis_obs')
lis_state1=read_trainingdata('lis_state1')
lis_state2=read_trainingdata('lis_state2')


testlis_obs,testlis_state,testlis_state2,tt=testdata(dict_obs,text)
sent_viterbi(tt,dict_postag,dict_obs,dict1,dict2,dict_past_tag,dict_updated_ftags,testlis_obs,testlis_state,lis_obs,lis_state1,dict_future_tag,testlis_state2)



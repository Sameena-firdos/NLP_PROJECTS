import pickle
import nltk
from nltk.tokenize import sent_tokenize,word_tokenize
from collections import OrderedDict
import math

def getsent(text):
	text=text.lower()
	lis_state1=[]
	lis_state2=[]
	lis_obs=[]
	i=0
	while(len(text)>0):
		i=0
		try:
			r,text = text.split('\n\n',1)
			#print text
			if i==0:
				lis_state1.append('/sw')
				lis_obs.append('/sw')
				lis_state2.append('/sw')
			while(len(r)>0):
				#i=0
				try:
					
					s,r=r.split('\n',1)
					#print s,"hjtfd\n"
					if (len(s)!=0):
						temp=s.split("\t")
						lis_state1.append(temp[1])
						lis_state2.append(temp[2])
						lis_obs.append(temp[0])


				except:
					#print r
					if (len(r)!=0):
						temp=r.split("\t")
						lis_state1.append(temp[1])
						lis_state2.append(temp[2])
						lis_obs.append(temp[0])
					break
				i+=1
			lis_state1.append('/ew')
			lis_state2.append('/ew')
			lis_obs.append('/ew')


			#print " "
			#print " "
		except:
			break

	#print " "
	#print " "
	lis_state1.append('/sw')
	lis_state2.append('/sw')
	lis_obs.append('/sw')
	while(len(text)>0):
		try:
			s,text=text.split('\n',1)
			if s=='\n':
				break
			#print s,"hjtfd"
			if len(s)!=0:
				temp=s.split("\t")
				lis_state1.append(temp[1])
				lis_state2.append(temp[2])
				lis_obs.append(temp[0])
		except:
			#print text
			if(len(text)!=0):
				temp=text.split("\t")
				lis_state1.append(temp[1])
				lis_state2.append(temp[2])
				lis_obs.append(temp[0])
			break
	lis_state1.append('/ew')
	lis_state2.append('/ew')
	lis_obs.append('/ew')


	'''print lis_obs
	print " "
	print " "
	print lis_state1
	print ""
	print " "
	print lis_state2'''
	if lis_obs[len(lis_obs)-1]=='/ew' and lis_obs[len(lis_obs)-2]=='/sw':
		del lis_obs[len(lis_obs)-2:len(lis_obs)]
	if lis_state1[len(lis_state1)-1]=='/ew' and lis_state1[len(lis_state1)-2]=='/sw':
		del lis_state1[len(lis_state1)-2:len(lis_state1)]
	if lis_state2[len(lis_state2)-1]=='/ew' and lis_state2[len(lis_state2)-2]=='/sw':
		del lis_state2[len(lis_state2)-2:len(lis_state2)]

	return lis_obs,lis_state1,lis_state2

			
def classify(lis_obs,lis_state1,lis_state2):
	dict_obs=OrderedDict() #contains word count
	dict_postag=OrderedDict()
	for i in lis_obs:
		if i in dict_obs.keys():
			dict_obs[i]+=1
		else:
			dict_obs[i]=1

	for i in lis_state1:
		if i in dict_postag.keys():
			dict_postag[i]+=1
		else:
			dict_postag[i]=1

	val=(100**100)
	for key in dict_obs:
		if val>dict_obs[key] and key!='/sw' and key!='/ew' :
			val=dict_obs[key]
	
	i=0
	
	temp=[]
	for key in dict_obs:
		if val==dict_obs[key] and key!='/sw' and key!='/ew': 
			temp.append(key)
			for i in range(0,len(lis_obs)):
				if lis_obs[i]==key:
					lis_obs[i]='<unk>'
	c=0
	for key in temp:
		c+=1
		dict_obs['<unk>'] = dict_obs.pop(key)
	dict_obs['<unk>']=c
	#print dict_obs
	#print lis_obs

	c_b=0;c_i=0;c_o=0
	c_bstart=0;c_istart=0;c_ostart=0
	c_bend=0;c_iend=0;c_oend=0
	for i in range(0,len(lis_obs)-1):
		if lis_obs[i]=='/ew':
			continue
		if lis_state2[i]=='b-np':
			c_b+=1
		if lis_state2[i]=='i-np':
			c_i+=1
		if lis_state2[i]=='o':
			c_o+=1
		if lis_state2[i]=='/sw':
			if lis_state2[i+1]=='b-np':
				c_bstart+=1
			if lis_state2[i+1]=='i-np':
				c_istart+=1
			if lis_state2[i+1]=='o':
				c_ostart+=1
		if lis_state2[i+1]=='/ew':
			if lis_state2[i]=='b-np':
				c_bend+=1
			if lis_state2[i]=='i-np':
				c_iend+=1
			if lis_state2[i]=='o':
				c_oend+=1
	B=(c_b,c_bstart,c_bend)
	I=(c_i,c_istart,c_iend)
	O=(c_o,c_ostart,c_oend)
	#print B," ",I," ",O
	dict1=OrderedDict()	#contains feature number 1 and 
	dict1['B']=B
	dict1['I']=I
	dict1['O']=O
	#print dict1

	dict2=OrderedDict()	#biotag with given word
	for i in range(0,len(lis_obs)):
		if lis_obs[i]=='/sw' or lis_obs[i]=='/ew':
			continue
		tag=lis_state2[i]
		if tag=='b-np':
			k='B'
		if tag=='i-np':
			k='I'
		if tag=='o':
			k='O'

		if k in dict2.keys():
			try:
				dict2[k][lis_obs[i]]+=1
			except:
				dict2[k][lis_obs[i]]=1
		else:
			dict2[k]={lis_obs[i]:1}
	#print dict2

	dict_past_tag=OrderedDict()      #stores pas tags
	dict_future_tag=OrderedDict()	#stores future tags

	for i in range(2,len(lis_obs)):
		if lis_obs[i]=='/sw' or lis_obs[i]=='/ew' or lis_obs[i-1]=='/sw' or lis_obs[i-1]=='/ew':
			continue
		if lis_obs[i] in dict_past_tag.keys():
			try:
				dict_past_tag[lis_obs[i]][lis_state1[i-1]]+=1
			except:
				dict_past_tag[lis_obs[i]][lis_state1[i-1]]=1
		else:
			dict_past_tag[lis_obs[i]]={lis_state1[i-1]:1}

	for i in range(1,len(lis_obs)):
		if lis_obs[i]=='/sw' or lis_obs[i]=='/ew' or lis_obs[i+1]=='/sw' or lis_obs[i+1]=='/ew':
			continue
		if lis_obs[i] in dict_future_tag.keys():
			try:
				dict_future_tag[lis_obs[i]][lis_state1[i+1]]+=1
			except:
				dict_future_tag[lis_obs[i]][lis_state1[i+1]]=1
		else:
			dict_future_tag[lis_obs[i]]={lis_state1[i+1]:1}

	#print "pas tags ",dict_past_tag
	#print "futur tags ",dict_future_tag
	dict_updated_ftags=OrderedDict()

	for k in dict_future_tag:
		val=-1
		t=''
		for tag in dict_future_tag[k]:
			if val<dict_postag[tag]:
				val=dict_postag[tag]
				t=tag
		dict_updated_ftags[k]=t
	#print dict_updated_ftags

	return dict_postag,dict_obs,dict1,dict2,dict_past_tag,dict_updated_ftags,dict_future_tag


			








		
















def write_trainingdata(d,name):
	dbfile = open(name, 'wb') 
	pickle.dump(d, dbfile)
	dbfile.close()








print "Enter file memm training"
text=raw_input()

text = open(text, 'r')
text=text.read()
#print text
lis_obs,lis_state1,lis_state2=getsent(text)

dict_postag,dict_obs,dict1,dict2,dict_past_tag,dict_updated_ftags,dict_future_tag=classify(lis_obs,lis_state1,lis_state2)
write_trainingdata(dict_postag,'dict_postag')
write_trainingdata(dict_obs,'dict_obs')
write_trainingdata(dict1,'dict1')
write_trainingdata(dict2,'dict2')
write_trainingdata(dict_past_tag,'dict_past_tag')
write_trainingdata(dict_updated_ftags,'dict_updated_ftags')
write_trainingdata(dict_future_tag,'dict_future_tag')
write_trainingdata(lis_obs,'lis_obs')
write_trainingdata(lis_state1,'lis_state1')
write_trainingdata(lis_state2,'lis_state2')




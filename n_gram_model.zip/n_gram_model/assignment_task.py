import pickle
import re
import math
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
lis=['baseball',    #0
'motorcycles',#1
'msc',#2
'atheism',#3
'graphics',#4
'pchardware',#5
'machardware',#6
'windows',#7
'forsale',#8
'autos',#9
'hockey',#10
'crypt',#11
'electronics',#12
'med',#13
'space',#14
'religion',#15
'guns',#16
'politics',#17
'pmis',#18
'rmis']#19
dic_motor={}
dic_baseball={}
dic_atheism={}
dic_graphics={}
dic_msc={}
dic_pchardware={}
dic_machardware={}
dic_windows={}
dic_forsale={}
dic_autos={}
dic_hockey={}
dic_crypt={}
dic_electronics={}
dic_med={}
dic_space={}
dic_religion={}
dic_guns={}
dic_politics={}
dic_pmis={}
dic_rmis={}
pclass={} #stores probability of all class in multiclass




v1=set()
v2=set()





def load_dict(text):
	global dic_baseball
	global dic_motor
	global dic_msc
	global dic_atheism
	global dic_graphics
	global dic_pchardware
	global dic_machardware
	global dic_windows
	global dic_forsale
	global dic_autos
	global dic_hockey
	global dic_crypt
	global dic_electronics
	global dic_med
	global dic_space
	global dic_religion
	global dic_guns
	global dic_politics
	global dic_pmis
	global dic_rmis
	class1 = open('baseball', 'rb')
	dic_baseball= pickle.load(class1)
	#print dic_baseball['baseball']
	class2=open('motorcycles','rb')
	dic_motor=pickle.load(class2)

	class3=open('atheism','rb')
	dic_atheism=pickle.load(class3)

	class4=open('graphics','rb')
	dic_graphics=pickle.load(class4)

	class2=open('msc','rb')
	dic_msc=pickle.load(class2)

	class2=open('pchardware','rb')
	dic_pchardware=pickle.load(class2)

	class2=open('machardware','rb')
	dic_machardware=pickle.load(class2)

	class2=open('windows','rb')
	dic_windows=pickle.load(class2)

	class2=open('forsale','rb')
	dic_forsale=pickle.load(class2)

	class2=open('autos','rb')
	dic_autos=pickle.load(class2)

	class2=open('hockey','rb')
	dic_hockey=pickle.load(class2)

	class2=open('crypt','rb')
	dic_crypt=pickle.load(class2)

	class2=open('electronics','rb')
	dic_electronics=pickle.load(class2)
	class2=open('space','rb')
	dic_space=pickle.load(class2)
	class2=open('med','rb')
	dic_med=pickle.load(class2)
	class2=open('religion','rb')
	dic_religion=pickle.load(class2)
	class2=open('guns','rb')
	dic_guns=pickle.load(class2)

	class2=open('politics','rb')
	dic_politics=pickle.load(class2)

	class2=open('pmis','rb')
	dic_pmis=pickle.load(class2)
	class2=open('rmis','rb')
	dic_rmis=pickle.load(class2)



def process_text(text):
	tlis=[]
	text=text.lower()
	tokens = word_tokenize(text)
	stop_words = set(stopwords.words('english'))
	word = [t for t in tokens if not t in stop_words]
	for i in word:
		#pro=re.compile(r'[^\w]*[0-9!@#$%^&*()_+={}:;<>?/\|.,-]+[^\w]*')
		pro=re.compile(r'.*[A-Za-z]+.*')
		match = re.search(pro, i)
		if match != None:
			i = re.sub(r'[0-9!@#$%^&*()_+={}:;<>?/\|.,-]*',"",i)
			pro=re.compile(r'[a-z]+[\'][a-z]+')
			match = re.search(pro, i) 
			if match==None: 
				if len(i)!=2 and len(i)!=1:
					tlis.append(i)
	stop_words = set(stopwords.words('english'))
	tokens= [t for t in tlis if not t in stop_words] #tokens of input file

	return tokens
def vocab1(dic): #for task1
	global v1
	for i in dic:
		v1.add(i)

def vocab2(dic):
	global v2
	for i in dic:
		v2.add(i)

def multiclassprob(tokens,k):
	global pclass;global v2;global lis
	global dic_baseball
	global dic_motor
	global dic_msc
	global dic_atheism
	global dic_graphics
	global dic_pchardware
	global dic_machardware
	global dic_windows
	global dic_forsale
	global dic_autos
	global dic_hockey
	global dic_crypt
	global dic_electronics
	global dic_med
	global dic_space
	global dic_religion
	global dic_guns
	global dic_politics
	global dic_pmis
	global dic_rmis
	all1={};all5={};all10={};all100={}
	total_document=(dic_motor['motorcycles']['no_doc']+dic_baseball['baseball']['no_doc']+dic_msc['msc']['no_doc']+
		dic_atheism['atheism']['no_doc']+dic_graphics['graphics']['no_doc']+dic_pchardware['pchardware']['no_doc']+
		dic_machardware['machardware']['no_doc']+dic_windows['windows']['no_doc']+dic_forsale['forsale']['no_doc']+
		dic_autos['autos']['no_doc']+dic_hockey['hockey']['no_doc']+dic_crypt['crypt']['no_doc']+dic_electronics['electronics']['no_doc']+
		dic_med['med']['no_doc']+dic_space['space']['no_doc']+dic_religion['religion']['no_doc']+dic_guns['guns']['no_doc']+
		dic_politics['politics']['no_doc']+dic_pmis['pmis']['no_doc']+dic_rmis['rmis']['no_doc'])
	temp=dic_motor['motorcycles']['no_doc']/(float)(total_document)

	pclass['motorcycles']=temp
	pclass['baseball']=dic_baseball['baseball']['no_doc']/(float)(total_document)
	pclass['msc']=dic_msc['msc']['no_doc']/(float)(total_document)
	pclass['atheism']=dic_atheism['atheism']['no_doc']/(float)(total_document)
	pclass['graphics']=dic_graphics['graphics']['no_doc']/(float)(total_document)
	pclass['pchardware']=dic_pchardware['pchardware']['no_doc']/(float)(total_document)
	pclass['machardware']=dic_machardware['machardware']['no_doc']/(float)(total_document)
	pclass['windows']=dic_windows['windows']['no_doc']/(float)(total_document)
	pclass['forsale']=dic_forsale['forsale']['no_doc']/(float)(total_document)
	pclass['autos']=dic_autos['autos']['no_doc']/(float)(total_document)
	pclass['hockey']=dic_hockey['hockey']['no_doc']/(float)(total_document)
	pclass['crypt']=dic_crypt['crypt']['no_doc']/(float)(total_document)
	pclass['electronics']=dic_electronics['electronics']['no_doc']/(float)(total_document)
	pclass['med']=dic_med['med']['no_doc']/(float)(total_document)
	pclass['space']=dic_space['space']['no_doc']/(float)(total_document)
	pclass['religion']=dic_religion['religion']['no_doc']/(float)(total_document)
	pclass['guns']=dic_guns['guns']['no_doc']/(float)(total_document)
	pclass['politics']=dic_politics['politics']['no_doc']/(float)(total_document)
	pclass['pmis']=dic_pmis['pmis']['no_doc']/(float)(total_document)
	pclass['rmis']=dic_rmis['rmis']['no_doc']/(float)(total_document)

	#print pclass
	vocab2(dic_motor['motorcycles'])
	vocab2(dic_baseball['baseball'])
	vocab2(dic_msc['msc'])
	vocab2(dic_atheism['atheism'])
	vocab2(dic_graphics['graphics'])
	vocab2(dic_pchardware['pchardware'])
	vocab2(dic_machardware['machardware'])
	vocab2(dic_windows['windows'])
	vocab2(dic_forsale['forsale'])
	vocab2(dic_autos['autos'])
	vocab2(dic_hockey['hockey'])
	vocab2(dic_crypt['crypt'])
	vocab2(dic_electronics['electronics'])
	vocab2(dic_med['med'])
	vocab2(dic_space['space'])
	vocab2(dic_religion['religion'])
	vocab2(dic_guns['guns'])
	vocab2(dic_politics['politics'])
	vocab2(dic_pmis['pmis'])
	vocab2(dic_rmis['rmis'])

	#motor
	value_motor=0
	value_motor+=math.log(pclass['motorcycles'],10)
	logcp_motor=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_motor['motorcycles'][word] +k)/(float)(dic_motor['motorcycles']['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_motor.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_motor['motorcycles']['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_motor.append(math.log(val,10))
	for t in logcp_motor:
		value_motor+=t
	if k==1:
		all1[lis[1]]=value_motor
	if k==5:
		all5[lis[1]]=value_motor
	if k==10:
		all10[lis[1]]=value_motor
	if k==100:
		all100[lis[1]]=value_motor
	
	#baseball
	value_motor=0
	value_motor+=math.log(pclass[lis[0]],10)

	logcp_baseball=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_baseball[lis[0]][word] +k)/(float)(dic_baseball[lis[0]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_baseball.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_baseball[lis[0]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_baseball.append(math.log(val,10))
	for t in logcp_baseball:
		value_motor+=t
	if k==1:
		all1[lis[0]]=value_motor
	if k==5:
		all5[lis[0]]=value_motor
	if k==10:
		all10[lis[0]]=value_motor
	if k==100:
		all100[lis[0]]=value_motor

	#msc
	value_motor=0
	value_motor+=math.log(pclass[lis[2]],10)

	logcp_msc=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_msc[lis[2]][word] +k)/(float)(dic_msc[lis[2]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_msc.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_msc[lis[2]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_msc.append(math.log(val,10))
	for t in logcp_msc:
		value_motor+=t
	if k==1:
		all1[lis[2]]=value_motor
	if k==5:
		all5[lis[2]]=value_motor
	if k==10:
		all10[lis[2]]=value_motor
	if k==100:
		all100[lis[2]]=value_motor

	#atheism
	value_motor=0
	value_motor+=math.log(pclass[lis[3]],10)

	logcp_atheism=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_atheism[lis[3]][word] +k)/(float)(dic_atheism[lis[3]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_atheism.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_atheism[lis[3]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_atheism.append(math.log(val,10))
	for t in logcp_atheism:
		value_motor+=t
	if k==1:
		all1[lis[3]]=value_motor
	if k==5:
		all5[lis[3]]=value_motor
	if k==10:
		all10[lis[3]]=value_motor
	if k==100:
		all100[lis[3]]=value_motor

	#graphics
	value_motor=0
	value_motor+=math.log(pclass[lis[4]],10)

	logcp_graphics=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_graphics[lis[4]][word] +k)/(float)(dic_graphics[lis[4]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_graphics.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_graphics[lis[4]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_graphics.append(math.log(val,10))
	for t in logcp_graphics:
		value_motor+=t
	if k==1:
		all1[lis[4]]=value_motor
	if k==5:
		all5[lis[4]]=value_motor
	if k==10:
		all10[lis[4]]=value_motor
	if k==100:
		all100[lis[4]]=value_motor

	#pchardware
	value_motor=0
	value_motor+=math.log(pclass[lis[5]],10)

	logcp_pchardware=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_pchardware[lis[5]][word] +k)/(float)(dic_pchardware[lis[5]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_pchardware.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_pchardware[lis[5]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_pchardware.append(math.log(val,10))
	for t in logcp_pchardware:
		value_motor+=t
	if k==1:
		all1[lis[5]]=value_motor
	if k==5:
		all5[lis[5]]=value_motor
	if k==10:
		all10[lis[5]]=value_motor
	if k==100:
		all100[lis[5]]=value_motor

	#machardware
	value_motor=0
	value_motor+=math.log(pclass[lis[6]],10)

	logcp_machardware=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_machardware[lis[6]][word] +k)/(float)(dic_machardware[lis[6]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_machardware.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_machardware[lis[6]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_machardware.append(math.log(val,10))
	for t in logcp_machardware:
		value_motor+=t
	if k==1:
		all1[lis[6]]=value_motor
	if k==5:
		all5[lis[6]]=value_motor
	if k==10:
		all10[lis[6]]=value_motor
	if k==100:
		all100[lis[6]]=value_motor
	#windows
	value_motor=0
	value_motor+=math.log(pclass[lis[7]],10)

	logcp_windows=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_windows[lis[7]][word] +k)/(float)(dic_windows[lis[7]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_windows.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_windows[lis[7]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_windows.append(math.log(val,10))
	for t in logcp_windows:
		value_motor+=t
	if k==1:
		all1[lis[7]]=value_motor
	if k==5:
		all5[lis[7]]=value_motor
	if k==10:
		all10[lis[7]]=value_motor
	if k==100:
		all100[lis[7]]=value_motor
	#forsale
	value_motor=0
	value_motor+=math.log(pclass[lis[8]],10)

	logcp_forsale=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_forsale[lis[8]][word] +k)/(float)(dic_forsale[lis[8]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_forsale.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_forsale[lis[8]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_forsale.append(math.log(val,10))
	for t in logcp_forsale:
		value_motor+=t
	if k==1:
		all1[lis[8]]=value_motor
	if k==5:
		all5[lis[8]]=value_motor
	if k==10:
		all10[lis[8]]=value_motor
	if k==100:
		all100[lis[8]]=value_motor

	#autos
	value_motor=0
	value_motor+=math.log(pclass[lis[9]],10)

	logcp_autos=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_autos[lis[9]][word] +k)/(float)(dic_autos[lis[9]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_autos.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_autos[lis[9]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_autos.append(math.log(val,10))
	for t in logcp_autos:
		value_motor+=t
	if k==1:
		all1[lis[9]]=value_motor
	if k==5:
		all5[lis[9]]=value_motor
	if k==10:
		all10[lis[9]]=value_motor
	if k==100:
		all100[lis[9]]=value_motor

	#hockey
	value_motor=0
	value_motor+=math.log(pclass[lis[10]],10)

	logcp_hockey=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_hockey[lis[10]][word] +k)/(float)(dic_hockey[lis[10]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_hockey.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_hockey[lis[10]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_hockey.append(math.log(val,10))
	for t in logcp_hockey:
		value_motor+=t
	if k==1:
		all1[lis[10]]=value_motor
	if k==5:
		all5[lis[10]]=value_motor
	if k==10:
		all10[lis[10]]=value_motor
	if k==100:
		all100[lis[10]]=value_motor

	#crypt
	value_motor=0
	value_motor+=math.log(pclass[lis[11]],10)

	logcp_crypt=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_crypt[lis[11]][word] +k)/(float)(dic_crypt[lis[11]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_crypt.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_crypt[lis[11]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_crypt.append(math.log(val,10))
	for t in logcp_crypt:
		value_motor+=t
	if k==1:
		all1[lis[11]]=value_motor
	if k==5:
		all5[lis[11]]=value_motor
	if k==10:
		all10[lis[11]]=value_motor
	if k==100:
		all100[lis[11]]=value_motor

	#electronics
	value_motor=0
	value_motor+=math.log(pclass[lis[12]],10)

	logcp_electronics=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_electronics[lis[12]][word] +k)/(float)(dic_electronics[lis[12]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_electronics.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_electronics[lis[12]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_electronics.append(math.log(val,10))
	for t in logcp_electronics:
		value_motor+=t
	if k==1:
		all1[lis[12]]=value_motor
	if k==5:
		all5[lis[12]]=value_motor
	if k==10:
		all10[lis[12]]=value_motor
	if k==100:
		all100[lis[12]]=value_motor
	#med
	value_motor=0
	value_motor+=math.log(pclass[lis[13]],10)

	logcp_med=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_med[lis[13]][word] +k)/(float)(dic_med[lis[13]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_med.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_med[lis[13]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_med.append(math.log(val,10))
	for t in logcp_med:
		value_motor+=t
	if k==1:
		all1[lis[13]]=value_motor
	if k==5:
		all5[lis[13]]=value_motor
	if k==10:
		all10[lis[13]]=value_motor
	if k==100:
		all100[lis[13]]=value_motor
	#space
	value_motor=0
	value_motor+=math.log(pclass[lis[14]],10)

	logcp_space=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_space[lis[14]][word] +k)/(float)(dic_space[lis[14]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_space.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_space[lis[14]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_space.append(math.log(val,10))
	for t in logcp_space:
		value_motor+=t
	if k==1:
		all1[lis[14]]=value_motor
	if k==5:
		all5[lis[14]]=value_motor
	if k==10:
		all10[lis[14]]=value_motor
	if k==100:
		all100[lis[14]]=value_motor
	#religion
	value_motor=0
	value_motor+=math.log(pclass[lis[15]],10)

	logcp_religion=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_religion[lis[15]][word] +k)/(float)(dic_religion[lis[15]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_religion.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_religion[lis[15]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_religion.append(math.log(val,10))
	for t in logcp_religion:
		value_motor+=t
	if k==1:
		all1[lis[15]]=value_motor
	if k==5:
		all5[lis[15]]=value_motor
	if k==10:
		all10[lis[15]]=value_motor
	if k==100:
		all100[lis[15]]=value_motor

	#guns
	value_motor=0
	value_motor+=math.log(pclass[lis[16]],10)

	logcp_guns=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_guns[lis[16]][word] +k)/(float)(dic_guns[lis[16]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_guns.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_guns[lis[16]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_guns.append(math.log(val,10))
	for t in logcp_guns:
		value_motor+=t
	if k==1:
		all1[lis[16]]=value_motor
	if k==5:
		all5[lis[16]]=value_motor
	if k==10:
		all10[lis[16]]=value_motor
	if k==100:
		all100[lis[16]]=value_motor
	#politics
	value_motor=0
	value_motor+=math.log(pclass[lis[17]],10)

	logcp_politics=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_politics[lis[17]][word] +k)/(float)(dic_politics[lis[17]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_politics.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_politics[lis[17]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_politics.append(math.log(val,10))
	for t in logcp_politics:
		value_motor+=t
	if k==1:
		all1[lis[17]]=value_motor
	if k==5:
		all5[lis[17]]=value_motor
	if k==10:
		all10[lis[17]]=value_motor
	if k==100:
		all100[lis[17]]=value_motor
	#pmis
	value_motor=0
	value_motor+=math.log(pclass[lis[18]],10)

	logcp_pmis=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_pmis[lis[18]][word] +k)/(float)(dic_pmis[lis[18]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_pmis.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_pmis[lis[18]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_pmis.append(math.log(val,10))
	for t in logcp_pmis:
		value_motor+=t
	if k==1:
		all1[lis[18]]=value_motor
	if k==5:
		all5[lis[18]]=value_motor
	if k==10:
		all10[lis[18]]=value_motor
	if k==100:
		all100[lis[18]]=value_motor
	#rmis
	value_motor=0
	value_motor+=math.log(pclass[lis[19]],10)

	logcp_rmis=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_rmis[lis[19]][word] +k)/(float)(dic_rmis[lis[19]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_rmis.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_rmis[lis[19]]['tot_word']+(k*len(v2))+(1*k))
			#print val
			logcp_rmis.append(math.log(val,10))
	for t in logcp_rmis:
		value_motor+=t
	if k==1:
		all1[lis[19]]=value_motor
	if k==5:
		all5[lis[19]]=value_motor
	if k==10:
		all10[lis[19]]=value_motor
	if k==100:
		all100[lis[19]]=value_motor

	if k==1:
		#dic_1all['motorcycles']=value_motor
		#dic_1all['baseball']=value_baseball
		max_val=max(all1,key=all1.get)
		if max_val=='motorcycles':
			max_val1='rec.motorcycles'
		if max_val=='baseball':
			max_val1='rec.sport.baseball'
		if max_val=='atheism':
			max_val1='alt.atheism'
		if max_val=='graphics':
			max_val1='comp.graphics'
		if max_val=='msc':
			max_val1='comp.os.ms-windows.misc'
		if max_val=='pchardware':
			max_val1='comp.sys.ibm.pc.hardware'
		if max_val=='machardware':
			max_val1='comp.sys.mac.hardware'
		if max_val=='windows':
			max_val1='comp.windows.x'
		if max_val=='forsale':
			max_val1='misc.forsale'
		if max_val=='autos':
			max_val1='rec.autos'
		if max_val=='hockey':
			max_val1='rec.sport.hockey'
		if max_val=='crypt':
			max_val1='sci.crypt'
		if max_val=='electronics':
			max_val1='sci.electronics'
		if max_val=='med':
			max_val1='sci.med'
		if max_val=='space':
			max_val1='sci.space'
		if max_val=='religion':
			max_val1='soc.religion.christian'
		if max_val=='guns':
			max_val1='talk.politics.guns'
		if max_val=='politics':
			max_val1='talk.politics.mideast'
		if max_val=='pmis':
			max_val1='talk.politics.misc'
		if max_val=='rmis':
			max_val1='talk.religion.misc'





		print "In task two for add 1 smoothing doc belong to ",max_val1," having probability ",all1[max_val]



		



	elif k==5:
		#dic_5all['motorcycles']=value_motor
		#dic_5all['baseball']=value_baseball
		max_val=max(all5,key=all5.get)
		if max_val=='motorcycles':
			max_val1='rec.motorcycles'
		if max_val=='baseball':
			max_val1='rec.sport.baseball'
		if max_val=='atheism':
			max_val1='alt.atheism'
		if max_val=='graphics':
			max_val1='comp.graphics'
		if max_val=='msc':
			max_val1='comp.os.ms-windows.misc'
		if max_val=='pchardware':
			max_val1='comp.sys.ibm.pc.hardware'
		if max_val=='machardware':
			max_val1='comp.sys.mac.hardware'
		if max_val=='windows':
			max_val1='comp.windows.x'
		if max_val=='forsale':
			max_val1='misc.forsale'
		if max_val=='autos':
			max_val1='rec.autos'
		if max_val=='hockey':
			max_val1='rec.sport.hockey'
		if max_val=='crypt':
			max_val1='sci.crypt'
		if max_val=='electronics':
			max_val1='sci.electronics'
		if max_val=='med':
			max_val1='sci.med'
		if max_val=='space':
			max_val1='sci.space'
		if max_val=='religion':
			max_val1='soc.religion.christian'
		if max_val=='guns':
			max_val1='talk.politics.guns'
		if max_val=='politics':
			max_val1='talk.politics.mideast'
		if max_val=='pmis':
			max_val1='talk.politics.misc'
		if max_val=='rmis':
			max_val1='talk.religion.misc'



		print "In task two for add 5 smoothing doc belong to ",max_val1," having probability ",all5[max_val]
		
		

	elif k==10:
		#dic_10all['motorcycles']=value_motor
		#dic_10all['baseball']=value_baseball
		max_val=max(all10,key=all10.get)
		if max_val=='motorcycles':
			max_val1='rec.motorcycles'
		if max_val=='baseball':
			max_val1='rec.sport.baseball'
		if max_val=='atheism':
			max_val1='alt.atheism'
		if max_val=='graphics':
			max_val1='comp.graphics'
		if max_val=='msc':
			max_val1='comp.os.ms-windows.misc'
		if max_val=='pchardware':
			max_val1='comp.sys.ibm.pc.hardware'
		if max_val=='machardware':
			max_val1='comp.sys.mac.hardware'
		if max_val=='windows':
			max_val1='comp.windows.x'
		if max_val=='forsale':
			max_val1='misc.forsale'
		if max_val=='autos':
			max_val1='rec.autos'
		if max_val=='hockey':
			max_val1='rec.sport.hockey'
		if max_val=='crypt':
			max_val1='sci.crypt'
		if max_val=='electronics':
			max_val1='sci.electronics'
		if max_val=='med':
			max_val1='sci.med'
		if max_val=='space':
			max_val1='sci.space'
		if max_val=='religion':
			max_val1='soc.religion.christian'
		if max_val=='guns':
			max_val1='talk.politics.guns'
		if max_val=='politics':
			max_val1='talk.politics.mideast'
		if max_val=='pmis':
			max_val1='talk.politics.misc'
		if max_val=='rmis':
			max_val1='talk.religion.misc'



		print "In task two for add 10 smoothing doc belong to ",max_val1," having probability ",all10[max_val]
		
		

	elif k==100:
		#dic_100all['motorcycles']=value_motor
		#dic_100all['baseball']=value_baseball
		max_val=max(all100,key=all100.get)
		if max_val=='motorcycles':
			max_val1='rec.motorcycles'
		if max_val=='baseball':
			max_val1='rec.sport.baseball'
		if max_val=='atheism':
			max_val1='alt.atheism'
		if max_val=='graphics':
			max_val1='comp.graphics'
		if max_val=='msc':
			max_val1='comp.os.ms-windows.misc'
		if max_val=='pchardware':
			max_val1='comp.sys.ibm.pc.hardware'
		if max_val=='machardware':
			max_val1='comp.sys.mac.hardware'
		if max_val=='windows':
			max_val1='comp.windows.x'
		if max_val=='forsale':
			max_val1='misc.forsale'
		if max_val=='autos':
			max_val1='rec.autos'
		if max_val=='hockey':
			max_val1='rec.sport.hockey'
		if max_val=='crypt':
			max_val1='sci.crypt'
		if max_val=='electronics':
			max_val1='sci.electronics'
		if max_val=='med':
			max_val1='sci.med'
		if max_val=='space':
			max_val1='sci.space'
		if max_val=='religion':
			max_val1='soc.religion.christian'
		if max_val=='guns':
			max_val1='talk.politics.guns'
		if max_val=='politics':
			max_val1='talk.politics.mideast'
		if max_val=='pmis':
			max_val1='talk.politics.misc'
		if max_val=='rmis':
			max_val1='talk.religion.misc'



		#print all100
		print "In task two for add 100 smoothing doc belong to ",max_val1," having probability ",all100[max_val]
		







def twoclassclassifier(tokens,k):
	#global dic_1all;global dic_5all;global dic_10all;global dic_100all
	
	p_motorcycles=dic_motor['motorcycles']['no_doc']/(float)(dic_motor['motorcycles']['no_doc']+dic_baseball['baseball']['no_doc'])
	p_baseball=dic_baseball['baseball']['no_doc']/(float)(dic_motor['motorcycles']['no_doc']+dic_baseball['baseball']['no_doc'])
	
	log_pmotor=math.log(p_motorcycles,10) #probability of motor class
	log_pbaseball=math.log(p_baseball,10) #probability of baseball class

	value_motor=log_pmotor
	value_baseball=log_pbaseball

	#print log_pbaseball," baseball ",log_pmotor," motor "
	vocab1(dic_motor['motorcycles'])
	vocab1(dic_baseball['baseball'])
	#print v1  #vocabulary size for two class classification

	#for class motor finding naive byes
	logcp_motor=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_motor['motorcycles'][word] +k)/(float)(dic_motor['motorcycles']['tot_word']+(k*len(v1))+(1*k))
			#print val
			logcp_motor.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_motor['motorcycles']['tot_word']+(k*len(v1))+(1*k))
			#print val
			logcp_motor.append(math.log(val,10))
	for t in logcp_motor:
		value_motor+=t

	#for class baseball finding naive byes
	logcp_baseball=[]	 #conditional probability of motor
	for word in tokens:
		try:
			val=(dic_baseball['baseball'][word] +k)/(float)(dic_baseball['baseball']['tot_word']+(k*len(v1))+(1*k))
			#print val
			logcp_baseball.append(math.log(val,10))
		except:
			val=(0+k)/(float)(dic_baseball['baseball']['tot_word']+(k*len(v1))+(1*k))
			#print val
			logcp_baseball.append(math.log(val,10))
	for t in logcp_baseball:
		value_baseball+=t

	print "Probability value for motorcycle class is ",value_motor
	print "Probability value for baseball class is ",value_baseball

	if k==1:
		#dic_1all['motorcycles']=value_motor
		#dic_1all['baseball']=value_baseball
		if value_motor>value_baseball:
			print "In task one for add 1 smoothing doc belong to motorcycle"
		else:
			print "In task one for add 1 smoothing doc belong to baseball"



	elif k==5:
		#dic_5all['motorcycles']=value_motor
		#dic_5all['baseball']=value_baseball
		if value_motor>value_baseball:
			print "In task one for add 5 smoothing doc belong to motorcycle"
		else:
			print "In task one for add 5 smoothing doc belong to baseball"
		

	elif k==10:
		#dic_10all['motorcycles']=value_motor
		#dic_10all['baseball']=value_baseball
		if value_motor>value_baseball:
			print "In task one for add 10 smoothing doc belong to motorcycle"
		else:
			print "In task one for add 10 smoothing doc belong to baseball"
		

	elif k==100:
		#dic_100all['motorcycles']=value_motor
		#dic_100all['baseball']=value_baseball
		if value_motor>value_baseball:
			print "In task one for add 100 smoothing doc belong to motorcycle"
		else:
			print "In task one for add 100 smoothing doc belong to baseball"

		





	

print "enter test data"
file_name=raw_input()
text = open(file_name, 'r')
text=text.read()
load_dict(text)
tokens=process_text(text)
twoclassclassifier(tokens,1)
print " "
twoclassclassifier(tokens,5)
print " "
twoclassclassifier(tokens,10)
print " "
twoclassclassifier(tokens,100)
print " "
multiclassprob(tokens,1)
print " "
multiclassprob(tokens,5)
print " "
multiclassprob(tokens,10)
print " "
multiclassprob(tokens,100)




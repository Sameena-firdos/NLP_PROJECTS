import pickle
import re
import glob
from nltk.tokenize import sent_tokenize,word_tokenize
dic_unigram={}
dic_bigram={}
dic_trigram={}


def unigram(lis,id):
	global dic_unigram
	for k in lis:         #count of unique words
		if k in dic_unigram.keys():
			dic_unigram[k]+=1
		else:
			dic_unigram[k]=1




def bigram(lis,id):
	global dic_bigram
	l=len(lis)
	i=0
	tt=0
	while i < (len(lis)):
		if i==-1:
			i=0
		if i==0 and tt==0:
			k='/sw'+' '+lis[i]
			tt=1
			i-=1

		elif l==1:
			k=lis[i]+' '+'/ew'
			i+=1
			l-=1
		else:
			k=lis[i]+' '+lis[i+1]
			i+=1
			l-=1
		if k in dic_bigram.keys():
			dic_bigram[k]+=1
		else:
			dic_bigram[k]=1
		#dic_bigram[lis[i]+' '+lis[i+1]]
		






def trigram(lis,id):
	global dic_trigram
	l=len(lis)
	i=0
	tt=0
	while i < (len(lis)-1):
		if i==-1:
			i=0
		if i==0 and tt==0:
			k='/sw'+' '+lis[i]+' '+lis[i+1]
			i-=1
			tt=1

		elif l==2:
			k=lis[i]+' '+lis[i+1]+' ' +'/ew'
			i+=1
			l-=1
		else:
			k=lis[i]+' '+lis[i+1]+' '+lis[i+2]
			i+=1
			l-=1
		if k in dic_bigram.keys():
			dic_trigram[k]+=1
		else:
			dic_trigram[k]=1
		#dic_bigram[lis[i]+' '+lis[i+1]]
		




def pre_process(text,id):

	global dic_unigram
	try:
		text = open(text, 'r')
		text=text.read()
	except:
		return 3
	first, text = text.split('\n\n',1)
	text=text.lower()
	try:
		se=sent_tokenize(text)
	except:
		return 3

	dic_unigram['/sw']=len(se) #start word /ew will be ending word
	for sent in se:

		lis=[]
		#print sent
		try:
			sent=word_tokenize(sent)
		except:
			continue
		for i in sent:
			pro=re.compile(r'.*[A-Za-z]+.*')
			match = re.search(pro, i)
			if match != None:
				i = re.sub(r'[0-9!@#$%^&*()_+={}:;<>?/\|.,-]*',"",i)
				pro=re.compile(r'[a-z]*[\'][a-z]*')
				match = re.search(pro, i) 
				if match==None:
					if len(i)!=1 or i=='a':
						lis.append(i)
		#print lis
		if id=="motorcycle":
			unigram(lis,"motorcycle")
			bigram(lis,"motorcycle")
			trigram(lis,"motorcycle")
		elif id=="baseball":
			unigram(lis,"baseball")
			bigram(lis,"baseball")
			trigram(lis,"baseball")






	return 1

def process():
	
	files=glob.glob("rec.motorcycles/*")
	i=0
	for file in files:
		print file
		val=pre_process(file,"motorcycle")
		i+=1
		

	global dic_trigram
	global dic_bigram
	global dic_unigram
	tot_word=0
	for k in dic_unigram:
		tot_word+=dic_unigram[k]
	#for k in dic_trigram:
		#print (k ," -> " ,dic_trigram[k]) 

	dic_unigram["tot_word"]=tot_word #total words in unigram
	

	#dump the dictionary of motorcycle in pickle
	db={}
	db["unigram"]=dic_unigram
	dbfile = open('motor_unigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["bigram"]=dic_bigram
	dbfile = open('motor_bigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["trigram"]=dic_trigram
	dbfile = open('motor_trigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()


	dic_unigram.clear()
	dic_bigram.clear()
	dic_trigram.clear()
	#now call for baseball
	files=glob.glob("rec.sport.baseball/*")
	i=0
	for file in files:
		print file
		val=pre_process(file,"baseball")
		i+=1
		

	global dic_trigram
	global dic_bigram
	global dic_unigram
	tot_word=0
	for k in dic_unigram:
		tot_word+=dic_unigram[k]
	#for k in dic_trigram:
		#print (k ," -> " ,dic_trigram[k])
	print tot_word 

	dic_unigram["tot_word"]=tot_word #total words in unigram

	#dump the dictionary of motorcycle in pickle
	db={}
	db["unigram"]=dic_unigram
	dbfile = open('baseball_unigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["bigram"]=dic_bigram
	dbfile = open('baseball_bigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["trigram"]=dic_trigram
	dbfile = open('baseball_trigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	
def counts_motor():
	dic_unigram={};dic_bigram={};dic_trigram={}
	c_unigram={};c_bigram={};c_trigram={}

	class1 = open('motor_unigram', 'rb')
	dic_unigram= pickle.load(class1)

	class1 = open('motor_bigram', 'rb')
	dic_bigram= pickle.load(class1)

	class1 = open('motor_trigram', 'rb')
	dic_trigram= pickle.load(class1)


	maxcount=-1
	for key in dic_unigram['unigram']:
		print "in unigram"
		if dic_unigram['unigram'][key]>maxcount:
			maxcount=dic_unigram['unigram'][key]

	i=maxcount+1
	while i>0:
		j=0
		print "in unigram",i
		for key in dic_unigram['unigram']:
			if dic_unigram['unigram'][key]==i:
				j+=1
		c_unigram[i]=j
		i-=1
	

	#bigram
	maxcount=-1
	for key in dic_bigram['bigram']:
		if dic_bigram['bigram'][key]>maxcount:
			maxcount=dic_bigram['bigram'][key]

	i=maxcount+1
	while i>0:
		j=0
		print "in bigram",i
		for key in dic_bigram['bigram']:
			if dic_bigram['bigram'][key]==i:
				j+=1
		c_bigram[i]=j
		i-=1

	#trigram
	maxcount=-1
	for key in dic_trigram['trigram']:
		if dic_trigram['trigram'][key]>maxcount:
			maxcount=dic_trigram['trigram'][key]

	i=maxcount+1
	while i>0:
		j=0
		print "in trigram",i
		for key in dic_trigram['trigram']:
			if dic_trigram['trigram'][key]==i:
				j+=1


		c_trigram[i]=j
		i-=1
	db={}
	db["unigram"]=c_unigram
	dbfile = open('countmotor_unigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["bigram"]=c_bigram
	dbfile = open('countmotor_bigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["trigram"]=c_trigram
	dbfile = open('countmotor_trigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()


def counts_baseball():
	dic_unigram={};dic_bigram={};dic_trigram={}
	c_unigram={};c_bigram={};c_trigram={}

	class1 = open('baseball_unigram', 'rb')
	dic_unigram= pickle.load(class1)

	class1 = open('baseball_bigram', 'rb')
	dic_bigram= pickle.load(class1)

	class1 = open('baseball_trigram', 'rb')
	dic_trigram= pickle.load(class1)


	maxcount=-1
	for key in dic_unigram['unigram']:
		print "in unigram"
		if dic_unigram['unigram'][key]>maxcount:
			maxcount=dic_unigram['unigram'][key]

	i=maxcount+1
	while i>0:
		j=0
		print "in unigram",i
		for key in dic_unigram['unigram']:
			if dic_unigram['unigram'][key]==i:
				j+=1
		c_unigram[i]=j
		i-=1
	

	#bigram
	maxcount=-1
	for key in dic_bigram['bigram']:
		if dic_bigram['bigram'][key]>maxcount:
			maxcount=dic_bigram['bigram'][key]

	i=maxcount+1
	while i>0:
		j=0
		print "in bigram",i
		for key in dic_bigram['bigram']:
			if dic_bigram['bigram'][key]==i:
				j+=1
		c_bigram[i]=j
		i-=1

	#trigram
	maxcount=-1
	for key in dic_trigram['trigram']:
		if dic_trigram['trigram'][key]>maxcount:
			maxcount=dic_trigram['trigram'][key]

	i=maxcount+1
	while i>0:
		j=0
		print "in trigram",i
		for key in dic_trigram['trigram']:
			if dic_trigram['trigram'][key]==i:
				j+=1


		c_trigram[i]=j
		i-=1
	db={}
	db["unigram"]=c_unigram
	dbfile = open('countbaseball_unigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["bigram"]=c_bigram
	dbfile = open('countbaseball_bigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["trigram"]=c_trigram
	dbfile = open('countbaseball_trigram', 'wb') 
	pickle.dump(db, dbfile)
	dbfile.close()

	

process()
counts_motor()
counts_baseball()


	

import codecs
import string
import re
import pickle
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
import glob
lis_motor=[]
dic_motor={}
lis_atheism=[]
dic_atheism={}
lis_graphics=[]
dic_graphics={}
lis_msc=[]
dic_msc={};lis_baseball=[];dic_baseball={};lis_pchardware=[];dic_pchardware={};lis_machardware=[]
dic_machardware={}
lis_windows=[];dic_windows={};lis_forsale=[];dic_forsale={};lis_autos=[];dic_autos={};lis_hockey=[];dic_hockey={};lis_crypt=[]
dic_crypt={};lis_electronics=[];dic_electronics={};lis_med=[];dic_med={}
lis_space=[];dic_space={};lis_religion=[];dic_religion={};lis_guns=[];dic_guns={}
lis_politics=[];dic_politics={}
lis_pmis=[];dic_pmis={}
lis_rmis=[];dic_rmis={}
def save_val(dir_name):
	db={}
	if dir_name=="rec.motorcycles":
		#lis_motor.append(t)
		db["motorcycles"]=dic_motor
		dbfile = open('motorcycles', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close() 

	elif dir_name=="alt.atheism":
		#lis_atheism.append(t)
		db["atheism"]=dic_atheism
		dbfile = open('atheism', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()

	elif dir_name=="comp.graphics":
		#lis_graphics.append(t)
		db["graphics"]=dic_graphics
		dbfile = open('graphics', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()

	elif dir_name=="windows.msc":
		#lis_msc.append(t)
		db["msc"]=dic_msc
		dbfile = open('msc', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()

	elif dir_name=="baseball":
		#lis_baseball.append(t)
		db["baseball"]=dic_baseball
		dbfile = open('baseball', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="pchardware":
		#lis_baseball.append(t)
		db["pchardware"]=dic_pchardware
		dbfile = open('pchardware', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="machardware":
		#lis_baseball.append(t)
		db["machardware"]=dic_machardware
		dbfile = open('machardware', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="windows":
		#lis_baseball.append(t)
		db["windows"]=dic_windows
		dbfile = open('windows', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="forsale":
		#lis_baseball.append(t)
		db["forsale"]=dic_forsale
		dbfile = open('forsale', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="autos":
		#lis_baseball.append(t)
		db["autos"]=dic_autos
		dbfile = open('autos', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="hockey":
		#lis_baseball.append(t)
		db["hockey"]=dic_hockey
		dbfile = open('hockey', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="crypt":
		#lis_baseball.append(t)
		db["crypt"]=dic_crypt
		dbfile = open('crypt', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="electronics":
		#lis_baseball.append(t)
		db["electronics"]=dic_electronics
		dbfile = open('electronics', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="med":
		#lis_baseball.append(t)
		db["med"]=dic_med
		dbfile = open('med', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="space":
		#lis_baseball.append(t)
		db["space"]=dic_space
		dbfile = open('space', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="religion":
		#lis_baseball.append(t)
		db["religion"]=dic_religion
		dbfile = open('religion', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="guns":
		#lis_baseball.append(t)
		db["guns"]=dic_guns
		dbfile = open('guns', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="politics":
		#lis_baseball.append(t)
		db["politics"]=dic_politics
		dbfile = open('politics', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="pmis":
		#lis_baseball.append(t)
		db["pmis"]=dic_pmis
		dbfile = open('pmis', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()
	elif dir_name=="rmis":
		#lis_baseball.append(t)
		db["rmis"]=dic_rmis
		dbfile = open('rmis', 'wb') 
		# source, destination 
		pickle.dump(db, dbfile)
		dbfile.close()


def pre_process(text,dir_name):
	tlis=[]
	try:
		text = open(text, 'r')
		text=text.read()
	except:
		return 3

	'''fp = codecs.open(file,"r",encoding='utf-8', errors='ignore')
	text = fp.read()'''
	first, text = text.split('\n\n',1)
	text=text.lower() # make a new file and write the rest
	try:
		tokens = word_tokenize(text)
	except:
		return 3
	#print tokens
	stop_words = set(stopwords.words('english'))
	word = [t for t in tokens if not t in stop_words]
	#print word
	for i in word:
		#pro=re.compile(r'[^\w]*[0-9!@#$%^&*()_+={}:;<>?/\|.,-]+[^\w]*')
		pro=re.compile(r'.*[A-Za-z]+.*')
		match = re.search(pro, i)
		if match != None:
			i = re.sub(r'[0-9!@#$%^&*()_+={}:;<>?/\|.,-]*',"",i)
			pro=re.compile(r'[a-z]+[\'][a-z]+')
			match = re.search(pro, i) 
			if match==None: 
				if len(i)!=2 and len(i)!=1:
					tlis.append(i)
	print "Temporary list of particular file"
	print tlis
	print "again PROCESS @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
	stop_words = set(stopwords.words('english'))
	for t in tlis:   #appending all files data of particular directory 
		if not t in stop_words:
			if dir_name=="rec.motorcycles":
				lis_motor.append(t)
			elif dir_name=="alt.atheism":
				lis_atheism.append(t)
			elif dir_name=="comp.graphics":
				lis_graphics.append(t)
			elif dir_name=="windows.msc":
				lis_msc.append(t)
			elif dir_name=="baseball":
				lis_baseball.append(t)
			elif dir_name=="pchardware":
				lis_pchardware.append(t)
			elif dir_name=="machardware":
				lis_machardware.append(t)
			elif dir_name=="windows":
				lis_windows.append(t)
			elif dir_name=="forsale":
				lis_forsale.append(t)
			elif dir_name=="autos":
				lis_autos.append(t)
			elif dir_name=="hockey":
				lis_hockey.append(t)
			elif dir_name=="crypt":
				lis_crypt.append(t)
			elif dir_name=="electronics":
				lis_electronics.append(t)
			elif dir_name=="med":
				lis_med.append(t)
			elif dir_name=="space":
				lis_space.append(t)
			elif dir_name=="religion":
				lis_religion.append(t)
			elif dir_name=="guns":
				lis_guns.append(t)
			elif dir_name=="politics":
				lis_politics.append(t)
			elif dir_name=="pmis":
				lis_pmis.append(t)
			elif dir_name=="rmis":
				lis_rmis.append(t)
	return 1
	



def class_motorcycle():
	
	num_doc=0
	tot_word=0
	files=glob.glob("rec.motorcycles/*") 
	i=0  
	for file in files: 
		print file
		num_doc+=1
		val=pre_process(file,"rec.motorcycles")
		if val==3:
			num_doc-=1
			continue
		#if num_doc==500:
			#break
	print num_doc
	dic_motor["no_doc"]=num_doc # give total document in claass

	for k in lis_motor:         #count of unique words
		if k in dic_motor.keys():
			dic_motor[k]+=1
		else:
			dic_motor[k]=1
	print "dictionary is"

	for k in dic_motor:
		tot_word+=dic_motor[k]

		print (k ," -> " ,dic_motor[k])
	dic_motor["tot_word"]=tot_word #total words of class

	save_val("rec.motorcycles")

def class_atheism():
	
	num_doc=0
	tot_word=0
	files=glob.glob("alt.atheism/*") 
	i=0  
	for file in files: 
		print file
		num_doc+=1
		val=pre_process(file,"alt.atheism")
		if val==3:
			num_doc-=1
			continue
		#if num_doc==500:
			#break
	print num_doc
	dic_atheism["no_doc"]=num_doc # give total document in claass

	for k in lis_atheism:         #count of unique words
		if k in dic_atheism.keys():
			dic_atheism[k]+=1
		else:
			dic_atheism[k]=1
	print "dictionary is"

	
	for k in dic_atheism:
		tot_word+=dic_atheism[k]

		print (k ," -> " ,dic_atheism[k])
	dic_atheism["tot_word"]=tot_word

	save_val("alt.atheism")

def class_graphics():
	
	num_doc=0
	tot_word=0
	files=glob.glob("comp.graphics/*") 
	i=0  
	for file in files: 
		print file

		num_doc+=1
		val=pre_process(file,"comp.graphics")
		if val==3:
			num_doc-=1
			continue
		#if num_doc==500:
			#break
	print num_doc
	dic_graphics["no_doc"]=num_doc # give total document in claass

	for k in lis_graphics:         #count of unique words
		if k in dic_graphics.keys():
			dic_graphics[k]+=1
		else:
			dic_graphics[k]=1
	print "dictionary is"

	
	for k in dic_graphics:
		tot_word+=dic_graphics[k]

		print (k ," -> " ,dic_graphics[k])
	dic_graphics["tot_word"]=tot_word

	save_val("comp.graphics")


def class_msc():
	
	num_doc=0
	tot_word=0
	files=glob.glob("comp.os.ms-windows.misc/*") 
	i=0  
	for file in files: 
		print file
		num_doc+=1
		val=pre_process(file,"windows.msc")
		if val==3:
			num_doc-=1
			continue
		if num_doc==500:
			break
	print num_doc
	dic_msc["no_doc"]=num_doc # give total document in claass

	for k in lis_msc:         #count of unique words
		if k in dic_msc.keys():
			dic_msc[k]+=1
		else:
			dic_msc[k]=1
	print "dictionary is"

	
	for k in dic_msc:
		tot_word+=dic_msc[k]

		print (k ," -> " ,dic_msc[k])
	dic_msc["tot_word"]=tot_word

	save_val("windows.msc")

def class_baseball():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("rec.sport.baseball/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"baseball")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_baseball["no_doc"]=num_doc # give total document in claass

	for k in lis_baseball:         #count of unique words
		if k in dic_baseball.keys():
			dic_baseball[k]+=1
		else:
			dic_baseball[k]=1
	print "dictionary is"

	
	for k in dic_baseball:
		tot_word+=dic_baseball[k]

		print (k ," -> " ,dic_baseball[k])
	dic_baseball["tot_word"]=tot_word

	save_val("baseball")

def class_pchardware():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("comp.sys.ibm.pc.hardware/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"pchardware")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_pchardware["no_doc"]=num_doc # give total document in claass

	for k in lis_pchardware:         #count of unique words
		if k in dic_pchardware.keys():
			dic_pchardware[k]+=1
		else:
			dic_pchardware[k]=1
	print "dictionary is"

	
	for k in dic_pchardware:
		tot_word+=dic_pchardware[k]

		print (k ," -> " ,dic_pchardware[k])
	dic_pchardware["tot_word"]=tot_word

	save_val("pchardware")

def class_machardware():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("comp.sys.mac.hardware/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"machardware")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_machardware["no_doc"]=num_doc # give total document in claass

	for k in lis_machardware:         #count of unique words
		if k in dic_machardware.keys():
			dic_machardware[k]+=1
		else:
			dic_machardware[k]=1
	print "dictionary is"

	
	for k in dic_machardware:
		tot_word+=dic_machardware[k]

		print (k ," -> " ,dic_machardware[k])
	dic_machardware["tot_word"]=tot_word

	save_val("machardware")

def class_windows():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("comp.windows.x/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"windows")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_windows["no_doc"]=num_doc # give total document in claass

	for k in lis_windows:         #count of unique words
		if k in dic_windows.keys():
			dic_windows[k]+=1
		else:
			dic_windows[k]=1
	print "dictionary is"

	
	for k in dic_windows:
		tot_word+=dic_windows[k]

		print (k ," -> " ,dic_windows[k])
	dic_windows["tot_word"]=tot_word

	save_val("windows")

def class_forsale():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("misc.forsale/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"forsale")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_forsale["no_doc"]=num_doc # give total document in claass

	for k in lis_forsale:         #count of unique words
		if k in dic_forsale.keys():
			dic_forsale[k]+=1
		else:
			dic_forsale[k]=1
	print "dictionary is"

	
	for k in dic_forsale:
		tot_word+=dic_forsale[k]

		print (k ," -> " ,dic_forsale[k])
	dic_forsale["tot_word"]=tot_word

	save_val("forsale")

def class_autos():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("rec.autos/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"autos")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_autos["no_doc"]=num_doc # give total document in claass

	for k in lis_autos:         #count of unique words
		if k in dic_autos.keys():
			dic_autos[k]+=1
		else:
			dic_autos[k]=1
	print "dictionary is"

	
	for k in dic_autos:
		tot_word+=dic_autos[k]

		print (k ," -> " ,dic_autos[k])
	dic_autos["tot_word"]=tot_word

	save_val("autos")

def class_hockey():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("rec.sport.hockey/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"hockey")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_hockey["no_doc"]=num_doc # give total document in claass

	for k in lis_hockey:         #count of unique words
		if k in dic_hockey.keys():
			dic_hockey[k]+=1
		else:
			dic_hockey[k]=1
	print "dictionary is"

	
	for k in dic_hockey:
		tot_word+=dic_hockey[k]

		print (k ," -> " ,dic_hockey[k])
	dic_hockey["tot_word"]=tot_word

	save_val("hockey")

def class_crypt():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("sci.crypt/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"crypt")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_crypt["no_doc"]=num_doc # give total document in claass

	for k in lis_crypt:         #count of unique words
		if k in dic_crypt.keys():
			dic_crypt[k]+=1
		else:
			dic_crypt[k]=1
	print "dictionary is"

	
	for k in dic_crypt:
		tot_word+=dic_crypt[k]

		print (k ," -> " ,dic_crypt[k])
	dic_crypt["tot_word"]=tot_word

	save_val("crypt")

def class_electronics():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("sci.electronics/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"electronics")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_electronics["no_doc"]=num_doc # give total document in claass

	for k in lis_electronics:         #count of unique words
		if k in dic_electronics.keys():
			dic_electronics[k]+=1
		else:
			dic_electronics[k]=1
	print "dictionary is"

	
	for k in dic_electronics:
		tot_word+=dic_electronics[k]

		print (k ," -> " ,dic_electronics[k])
	dic_electronics["tot_word"]=tot_word

	save_val("electronics")

def class_med():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("sci.med/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"med")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_med["no_doc"]=num_doc # give total document in claass

	for k in lis_med:         #count of unique words
		if k in dic_med.keys():
			dic_med[k]+=1
		else:
			dic_med[k]=1
	print "dictionary is"

	
	for k in dic_med:
		tot_word+=dic_med[k]

		print (k ," -> " ,dic_med[k])
	dic_med["tot_word"]=tot_word

	save_val("med")

def class_space():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("sci.space/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"space")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_space["no_doc"]=num_doc # give total document in claass

	for k in lis_space:         #count of unique words
		if k in dic_space.keys():
			dic_space[k]+=1
		else:
			dic_space[k]=1
	print "dictionary is"

	
	for k in dic_space:
		tot_word+=dic_space[k]

		print (k ," -> " ,dic_space[k])
	dic_space["tot_word"]=tot_word

	save_val("space")

def class_religion():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("soc.religion.christian/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"religion")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_religion["no_doc"]=num_doc # give total document in claass

	for k in lis_religion:         #count of unique words
		if k in dic_religion.keys():
			dic_religion[k]+=1
		else:
			dic_religion[k]=1
	print "dictionary is"

	
	for k in dic_religion:
		tot_word+=dic_religion[k]

		print (k ," -> " ,dic_religion[k])
	dic_religion["tot_word"]=tot_word

	save_val("religion")

def class_guns():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("talk.politics.guns/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"guns")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_guns["no_doc"]=num_doc # give total document in claass

	for k in lis_guns:         #count of unique words
		if k in dic_guns.keys():
			dic_guns[k]+=1
		else:
			dic_guns[k]=1
	print "dictionary is"

	
	for k in dic_guns:
		tot_word+=dic_guns[k]

		print (k ," -> " ,dic_guns[k])
	dic_guns["tot_word"]=tot_word

	save_val("guns")

def class_politics():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("talk.politics.mideast/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"politics")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_politics["no_doc"]=num_doc # give total document in claass

	for k in lis_politics:         #count of unique words
		if k in dic_politics.keys():
			dic_politics[k]+=1
		else:
			dic_politics[k]=1
	print "dictionary is"

	
	for k in dic_politics:
		tot_word+=dic_politics[k]

		print (k ," -> " ,dic_politics[k])
	dic_politics["tot_word"]=tot_word

	save_val("politics")

def class_pmis():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("talk.politics.misc/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"pmis")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_pmis["no_doc"]=num_doc # give total document in claass

	for k in lis_pmis:         #count of unique words
		if k in dic_pmis.keys():
			dic_pmis[k]+=1
		else:
			dic_pmis[k]=1
	print "dictionary is"

	
	for k in dic_pmis:
		tot_word+=dic_pmis[k]

		print (k ," -> " ,dic_pmis[k])
	dic_pmis["tot_word"]=tot_word

	save_val("pmis")
def class_rmis():
	
	num_doc=0
	tot_word=0
	
	files=glob.glob("talk.religion.misc/*") 
	i=0  
	for file in files: 
		print file
		'''if file=="rec.sport.baseball/104352":
			continue'''
		num_doc+=1
		val=pre_process(file,"rmis")
		if val==3:
			num_doc-=1
			continue
		##if num_doc==500:
			#break
	print num_doc
	dic_rmis["no_doc"]=num_doc # give total document in claass

	for k in lis_rmis:         #count of unique words
		if k in dic_rmis.keys():
			dic_rmis[k]+=1
		else:
			dic_rmis[k]=1
	print "dictionary is"

	
	for k in dic_rmis:
		tot_word+=dic_rmis[k]

		print (k ," -> " ,dic_rmis[k])
	dic_rmis["tot_word"]=tot_word

	save_val("rmis")

	
#class_motorcycle()
#class_atheism()
#class_graphics()
#class_msc()
#class_baseball()
#class_pchardware()
#class_machardware()
#class_windows()
#class_forsale()
#class_autos()
#class_hockey()
#class_crypt()
#class_electronics()
#class_med()
#class_space()
#class_religion()
#class_guns()
#class_politics()
#class_pmis()
#class_rmis()



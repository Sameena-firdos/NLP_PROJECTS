import pickle
import nltk
from nltk.tokenize import sent_tokenize,word_tokenize

def data(text):
	lis_obs=[] #stores observation
	lis_states=[] #stores states
	r=""

	i=0
	while(len(text)>0):
		i=0
		try:
			r,text = text.split('\n.\t.\n\n',1)
			#print text
			if i==0:
				lis_states.append('/sw')
				lis_obs.append('/sw')
			while(len(r)>0):
				#i=0
				try:
					
					s,r=r.split('\n',1)
					#print s,"hjtfd\n"
					if (len(s)!=0):
						temp=s.split("\t")
						lis_states.append(temp[1])
						lis_obs.append(temp[0])


				except:
					#print r
					if (len(r)!=0):
						temp=r.split("\t")
						lis_states.append(temp[1])
						lis_obs.append(temp[0])
					break
				i+=1
			lis_states.append('/ew')
			lis_obs.append('/ew')


			print " "
			print " "
		except:
			break

	print " "
	print " "
	lis_states.append('/sw')
	lis_obs.append('/sw')
	while(len(text)>0):
		try:
			s,text=text.split('\n',1)
			if s=='\n' :
				break
			#print s,"hjtfd"
			if len(s)!=0:
				temp=s.split("\t")
				lis_states.append(temp[1])
				lis_obs.append(temp[0])
		except:
			#print textdel
			if(len(text)!=0):
				temp=text.split("\t")
				lis_states.append(temp[1])
				lis_obs.append(temp[0])
			break
	lis_states.append('/ew')
	lis_obs.append('/ew')


	#print lis_obs
	#print " "
	#print " "
	#print lis_states

	return lis_obs,lis_states


def dictionary_count(lis_obs,lis_states):
	dict_obs={} #dictionary of observation
	dict_states={}#dictionary of states
	for i in lis_obs:
		if i in dict_obs.keys():
			dict_obs[i]+=1
		else:
			dict_obs[i]=1
	for i in lis_states:
		if i in dict_states.keys():
			dict_states[i]+=1
		else:
			dict_states[i]=1


	#handle oov words
	val=(100**100)
	for key in dict_obs:
		if val>dict_obs[key] and key!='/sw' and key!='/ew' :
			val=dict_obs[key]
	#print "val is ",val
	i=0
	#replace obs state and dict_obs with <unk>
	temp=[]
	for key in dict_obs:
		if val==dict_obs[key] and key!='/sw' and key!='/ew':
			#dict_obs['<unk>'] = dict_obs.pop(key)
			#dict_obs['<unk>'] = dict_obs[key] 
			#del dict_obs[key] 
			temp.append(key)
			for i in range(0,len(lis_obs)):
				if lis_obs[i]==key:
					lis_obs[i]='<unk>'
	for key in temp:
		#print key
		dict_obs['<unk>'] = dict_obs.pop(key)





	#print dict_states
	print
	print
	#print dict_obs
	dict_nextstate={}#get count of q1 to q2

	for i in range(0,len(lis_states)-1):
		if lis_states[i]=='/ew':
			continue
		
		if lis_states[i] in dict_nextstate.keys():
			try:
				dict_nextstate[lis_states[i]][lis_states[i+1]]+=1
			except:
				dict_nextstate[lis_states[i]][lis_states[i+1]]=1
		else:
			dict_nextstate[lis_states[i]]={lis_states[i+1]:1}

	#print dict_nextstate

	dict_nextobs={}#get count of state and observation
	for i in range(0,len(lis_states)):
		if lis_states[i]=='/ew' or lis_states[i]=='/sw':
			continue
		if lis_states[i] in dict_nextobs.keys():
			try:
				dict_nextobs[lis_states[i]][lis_obs[i]]+=1
			except:
				dict_nextobs[lis_states[i]][lis_obs[i]]=1
		else:
			dict_nextobs[lis_states[i]]={lis_obs[i]:1}
	#print dict_nextobs
	return dict_nextobs,dict_nextstate,dict_states,dict_obs


def matrix(lis_obs,lis_states,dict_next_state,dict_next_obs,dict_states,dict_obs):
	print lis_obs
	print lis_states
	print dict_next_state
	print dict_next_obs
	print dict_states
	print dict_obs
	
	
	db={}
	db["next_state"]=dict_next_state
	dbfile = open('nextstate', 'wb') 
	# source, destination 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["next_obs"]=dict_next_obs
	dbfile = open('nextobs', 'wb') 
	# source, destination 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["states"]=dict_states
	dbfile = open('states', 'wb') 
	# source, destination 
	pickle.dump(db, dbfile)
	dbfile.close()
	db={}
	db["obs"]=dict_obs
	dbfile = open('obs', 'wb') 
	# source, destination 
	pickle.dump(db, dbfile)
	dbfile.close()
	




print "Enter file"
text=raw_input()

text = open(text, 'r')
text=text.read()
lis_obs,lis_states=data(text)
dict_next_obs,dict_next_state,dict_states,dict_obs=dictionary_count(lis_obs,lis_states)
matrix(lis_obs,lis_states,dict_next_state,dict_next_obs,dict_states,dict_obs)
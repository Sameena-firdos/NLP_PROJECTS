import pickle
import nltk
from nltk.tokenize import sent_tokenize,word_tokenize
def Find_tags(lis,dict_next_state,dict_next_obs,dict_states,dict_obs):
	print lis

	lis_states=[]
	temp1=[]
	temp2=[]
	tags=[]

	#lis_states.append('/sw')
	for key in dict_states['states']:
		if key!='/sw' and key!='/ew':
			lis_states.append(key) #all unique states
	
	#print lis_states
	#print dict_next_state['next_state']
	#print dict_states['states']
	'''print dict_states['states']
	print dict_next_obs['next_obs']'''
	#print lis_states

	p1=1
	p2=1
	for i in lis_states:
		#print i
		try:
			p1=dict_next_state['next_state']['/sw'][i]/(float)(dict_states['states']['/sw'])
		except:
			p1=0.0
		try:
			p2=dict_next_obs['next_obs'][i][lis[1]]/(float)(dict_states['states'][i])
		except:
			try:
				p2=dict_next_obs['next_obs'][i]['<unk>']/(float)(dict_states['states'][i])
			except:
				p2=0.0

		
		if p2!=0:
			temp1.append(p1*((float)(p2)))
		else:
			temp1.append(0)
	

	v=[]
	b=[]
	a=[]
	for i in temp1:
		a.append(i)
	v.append(a)

	for i in temp1:
		temp2.append(-1)
	b.append(temp2)
	
	p2=0
	p1=0
	for j in range(2,len(lis)-1):
		temp3=[] #v
		temp4=[] #b
		#print "lis j ",lis[j]
		for i in lis_states:
			#print "i ",i
			val=-1
			ss=-1
			#print temp1,44444444
			for k in xrange(0,len(temp1)):
				#print k," asdfg"
				try:
					p1=dict_next_state['next_state'][lis_states[k]][i]/(float)(dict_states['states'][lis_states[k]])
				except:
					p1=0
				#Sprint p1
				if val<(p1*temp1[k]):
					val=p1*temp1[k]
					ss=k
					#print k,"xxxxx"
			try:
				p2=dict_next_obs['next_obs'][i][lis[j]]/(float)(dict_states['states'][i])
			except:
				try:
					p2=dict_next_obs['next_obs'][i]['<unk>']/(float)(dict_states['states'][i])
				except:
					p2=0
			temp3.append(val*p2)
			temp4.append(ss)
		
		a=[]
		for i in temp3:
			a.append(i)
		
		v.append(a)
		
		a=[]
		for i in temp4:
			a.append(i)
		b.append(a)
		
		for i in range(0,len(temp3)):
			temp1[i]=temp3[i]

	#print "States are ",lis_states	
	#print "viterbi matrix is ",v
	#print "backtrace matrix is",b	
	print ""
	print ""
	
	

	x=0;y=0;val=-1
	show_states=[]
	i=len(lis)-3
	p1=0
	for j in range(0,len(lis_states)):
		try:
			p1=dict_next_state['next_state'][lis_states[j]]['/ew']/(float)(dict_states['states'][lis_states[j]])
		except:
			p1=0
				#Sprint p1
		if val<(p1*temp1[j]):
			val=p1*temp1[j]
			ss=j
	x=i
	y=ss



	for i in range (len(lis)-3,-1,-1):
		#print i
		if i==len(lis)-3:
			#print len(lis_states),"asuj"
			'''for j in range(0,len(lis_states)):
				#print j,"qqqqqqqqqqqqqqqqqqq"
				if val<v[i][j]:
					x=i;y=j
					val=v[i][j]'''
			show_states.append(lis_states[y])
			y=b[x][y]
			#print "y",y
		else:
			#print "in else"
			try:
				#print lis_states[y]
				show_states.append(lis_states[y])
				x=i
				y=b[x][y]
			except:
				break
	show_states.reverse()
	print show_states
	#writing states

	for i in range(1,len(lis)-1):
		f = open("hmm_output", "a")
		f.write(lis[i]+"\t"+show_states[i-1])
		f.write('\n')
	f.write('.\t.\n\n')
	f.close()





	print ""
	print ""













def getdata(text):
	class1= open('nextstate', 'rb')
	dict_next_state=pickle.load(class1)

	class1= open('nextobs', 'rb') #next_obs
	dict_next_obs=pickle.load(class1)

	class1= open('states', 'rb') #states
	dict_states=pickle.load(class1)

	class1= open('obs', 'rb') #obs
	dict_obs=pickle.load(class1)

	
	r=""

	#i=0
	while(len(text)>0):
		i=0
		lis_obs=[]
		try:
			r,text = text.split('\n.\t.\n\n',1)
			#print text
			if i==0:
				
				lis_obs.append('/sw')
			while(len(r)>0):
				#i=0
				try:
					
					s,r=r.split('\n',1)
					#print s,"hjtfd\n"
					if (len(s)!=0):
						temp=s.split("\t") #splitting of words
						
						lis_obs.append(temp[0])


				except:
					#print r
					if (len(r)!=0):
						temp=r.split("\t")
						
						lis_obs.append(temp[0])
					break
				i+=1
			
			lis_obs.append('/ew')
			#if i==1:																			#important
			Find_tags(lis_obs,dict_next_state,dict_next_obs,dict_states,dict_obs)


			
		except:
			break

	
	lis_obs=[]
	lis_obs.append('/sw')
	while(len(text)>0):
		try:
			s,text=text.split('\n',1)
			if s=='\n':
				break
			#print s,"hjtfd"
			if len(s)!=0:
				temp=s.split("\t")
				
				lis_obs.append(temp[0])
		except:
			#print text
			if(len(text)!=0):
				temp=text.split("\t")
				
				lis_obs.append(temp[0])
			break
	
	lis_obs.append('/ew')
	if lis_obs[len(lis_obs)-1]=='/ew' and lis_obs[len(lis_obs)-2]=='/sw':
		del lis_obs[len(lis_obs)-2:len(lis_obs)]
	if len(lis_obs)!=0:															#important
		Find_tags(lis_obs,dict_next_state,dict_next_obs,dict_states,dict_obs)
	























print "Enter file"
text=raw_input()

text = open(text, 'r')
text=text.read()
getdata(text)
import json
import re
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize
from collections import OrderedDict
from gensim.models.doc2vec import Doc2Vec, TaggedDocument
import string
import numpy
def data_extraction():
	data=[]
	for i in open('Easy.json', 'r'):
		data.append(json.loads(i,object_pairs_hook=OrderedDict))
	return data
	



def read_train_data():
	texti=open("data.txt","r")
	text=texti.read()
	text=text.lower()
	text=text.split("\n")
	list_data=[]
	s=set(string.punctuation)
	d=0
	for i in text:
		
		if len(i)==0:
			continue
		try:
			tokens = word_tokenize(i)
			stop_words=(set(stopwords.words('english')))
			word = [t for t in tokens if not t in stop_words and not t in s]
			temp=[]
			for w in word:
				w = re.sub(r'["0-9!@#$%^&*()_+=][{}:;<>?/\|.,-]*',"",w)
				w=re.sub(r'[^\x00-\x7f]',"",w)
				if w != '':
					temp.append(w)
			if len(temp)==0:
				continue
			list_data.append(temp)
		except:
			
			word=i.split()
			stop_words=(set(stopwords.words('english')))
			word = [t for t in tokens if not t in stop_words and not t in s]
			temp=[]
			for w in word:
				w = re.sub(r'["0-9!@#$%^&*()_][+={}:;<>?/\|.,-]*',"",w)
				w=re.sub(r'[^\x00-\x7f]',"",w)
				if w !=' ':
					temp.append(w)
			if len(temp)==0:
				continue
			list_data.append(temp)
	return list_data

def train_data(list_data):
	taged_data=[]
	for i in range(0,len(list_data)):
		taged_data.append(TaggedDocument(list_data[i],[str(i)]))
	#print taged_data
	model = Doc2Vec(vector_size=300,alpha=.041,min_alpha=0.041,min_count=0,dm =1,window=5)
	model.build_vocab(taged_data)
	for epoch in range(200):
		print('iteration {0}'.format(epoch))
		model.train(taged_data,total_examples=len(taged_data),epochs=model.iter)
		model.alpha -= 0.0002
		model.min_alpha = model.alpha

	model.save("d2v.model")


def test_data(dic):
	model=Doc2Vec.load("d2v.model")
	#v1 = model.infer_vector(["large","company","internation","involved","diamond"])
	#print("V1_infer", v1)
	s=set(string.punctuation)

	#similar_doc = model.most_similar('animal')
	#print(similar_doc)
	#print (model.docvecs['993'])
	score_value=[]
	questions=0
	num=0
	#print len(dic)
	for key in dic:
		#print ("#########################")
		q=key["question"]["stem"].lower()
		a=key["answerKey"]
		tex_label=[]
		simil=[]
		questions+=1

		for val in key["question"]["choices"]:
			tex_label.append(val["text"].lower())
			tex_label.append(val["label"])
		score=[]
		maxval=-1.0
		for i in range(0,len(tex_label),2):
			l=q+" "+tex_label[i]
			#print q
			#print a
			#print tex_label[i]
			#print tex_label[i+1]

			tokens = word_tokenize(l)
			stop_words=(set(stopwords.words('english')))
			word = [t for t in tokens if not t in stop_words and not t in s]

			temp=[]
			for w in word:
				w = re.sub(r'["0-9!@#$%^&*()_+=][{}:;<>?/\|.,-]*',"",w)
				w=re.sub(r'[^\x00-\x7f]',"",w)
				if w != '':
					temp.append(w)
			if len(temp)==0:
				continue
			a1=model.infer_vector(temp)
			a2=model.docvecs.most_similar([a1])[0]
			if maxval<a2[1]:
				maxval=a2[1]
			score.append(a2[1])
			score.append(tex_label[i+1])
			#print a2

		#print maxval
		totscore=0.0
		match=0.0
		notmatch=0.0
		
		for value in range(0,len(score),2):
			if score[value]==maxval:
				#print "score[i+1]",score[value+1],a
				if score[value+1]==a:
					match=1
					
					num+=1
				elif score[value+1]!=a:
					notmatch+=1
		print num
		if match==0:
			score_value.append(0)
		elif match==1:
			score_value.append(1.0/(match+notmatch))
			#print match,notmatch

	accuracy=0
	total=0
	for i in score_value:
		total+=i

	accuracy=total/float(questions)

	print "Total score is ",total
	print "Accuracy is ",accuracy






#list_data=read_train_data()
#train_data(list_data)
dic=data_extraction()
test_data(dic)
